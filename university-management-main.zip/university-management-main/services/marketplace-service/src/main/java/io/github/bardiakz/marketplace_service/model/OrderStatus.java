package io.github.bardiakz.marketplace_service.model;

public enum OrderStatus {
    PENDING,
    PAYMENT_PENDING,
    COMPLETED,
    FAILED,
    CANCELLED
}
