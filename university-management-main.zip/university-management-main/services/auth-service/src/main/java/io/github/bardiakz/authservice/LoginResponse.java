package io.github.bardiakz.authservice;

public record LoginResponse(String token, String username) {
}
