package io.github.bardiakz.authservice;

public record LoginRequest(String username, String password) {
}
