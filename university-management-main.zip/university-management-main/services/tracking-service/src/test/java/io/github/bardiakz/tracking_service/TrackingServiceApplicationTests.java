package io.github.bardiakz.tracking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrackingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
