rootProject.name = "resource-service"
